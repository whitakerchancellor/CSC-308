//
//  SpendingViewController.swift
//  Test3
//
//  Created by student on 5/7/18.
//  Copyright © 2018 cs@eku.edu. All rights reserved.
//

import UIKit
import CoreData

class SpendingViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    @IBOutlet weak var monthDayPicker: UIPickerView!
    @IBOutlet weak var categoryPicker: UIPickerView!
    @IBOutlet weak var amountText: UITextField!
    @IBOutlet weak var noteText: UITextField!
    
    @IBAction func dismissKeyboard(_ sender: Any) {
        self.view.endEditing(true)
    }
    
    @IBAction func addTransaction(_ sender: UIButton) {
        let parentVC = (parent as! T3TabBarController)          // shared data
        let entityTransaction = NSEntityDescription.entity(forEntityName: "Transactions", in: managedObjectContext)
        let transaction = Transactions(entity: entityTransaction!, insertInto: managedObjectContext)
        
        var alertTitle = ""         // convenience for alert
        var alertMessage = ""
        if amountText.text != "" {          // if a money amount was entered, save the data
            transaction.amount = amountText.text!
            transaction.category = parentVC.categories[categoryPicker.selectedRow(inComponent: 0)]
            transaction.day = String(monthDayPicker.selectedRow(inComponent: 1)+1)
            transaction.month = parentVC.months[monthDayPicker.selectedRow(inComponent: 0)].0
            transaction.note = noteText.text!
            do {
                try managedObjectContext.save()
            }
            catch let error {
                print(error.localizedDescription)
            }
            alertTitle = "Transaction Added!"
        } else {
            alertTitle = "Transaction Not Added!"           // if no money was entered, let the user know
            alertMessage = "Amount wasn't entered."
        }
        
        let alertController = UIAlertController(title: alertTitle,
                                                message: alertMessage,
                                                preferredStyle: UIAlertControllerStyle.alert)
        let defaultAction = UIAlertAction(title: "OK",
                                          style: UIAlertActionStyle.cancel,
                                          handler: nil)
        alertController.addAction(defaultAction)
        present(alertController, animated: true, completion: nil)
        
        amountText.text = ""            // reset text fields
        noteText.text = ""
    }
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        if pickerView.tag == 0 {            // first picker
            return 2
        } else {            // second picker
            return 1
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        let parentVC = (parent as! T3TabBarController)
        if pickerView.tag == 0 {            // first picker
            if component == 0 {         // months
                return parentVC.months.count
            } else {            // days
                return parentVC.months[parentVC.month].1
            }
        } else {            // second picker
            return parentVC.categories.count
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        let parentVC = (parent as! T3TabBarController)
        if pickerView.tag == 0 {            // first picker
            if component == 0 {         // months
                return parentVC.months[row].0
            } else {            // days
                return String(row+1)
            }
        } else {            // second picker
            return parentVC.categories[row]
        }
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView.tag == 0 && component == 0            // if the first component in the first picker was altered, update days
        {
            let parentVC = (parent as! T3TabBarController)
            parentVC.month = monthDayPicker.selectedRow(inComponent: 0)
            monthDayPicker.reloadComponent(1)
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
