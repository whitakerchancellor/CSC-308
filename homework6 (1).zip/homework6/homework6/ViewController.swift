//
//  ViewController.swift
//  homework6
//
//  Created by student on 3/22/18.
//  Copyright © 2018 cs@eku.edu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var categoryRandomizer = 0          // randomize the category
    var imageRandomizer = 0         // randomize the image
    var candidateRandomizer = 0         // randomize the candidate
    var temp = true         // while-loop control
    let images =
    [
        [
            UIImage(named: "Flower0.png")!,
            UIImage(named: "Flower1.png")!,
            UIImage(named: "Flower2.png")!,
            UIImage(named: "Flower3.png")!
        ],
        [
            UIImage(named: "Food0.png")!,
            UIImage(named: "Food1.png")!,
            UIImage(named: "Food2.png")!,
            UIImage(named: "Food3.png")!
        ],
        [
            UIImage(named: "Vehicle0.png")!,
            UIImage(named: "Vehicle1.png")!,
            UIImage(named: "Vehicle2.png")!,
            UIImage(named: "Vehicle3.png")!
        ]
    ]
    var unavailable = [34]          // keep track of the category image so it is not displayed again
    
    @IBOutlet weak var categoryImage: UIImageView!
    @IBOutlet weak var candidate1: UIButton!
    @IBOutlet weak var candidate2: UIButton!
    
    @IBAction func candidatePress(_ sender: UIButton) {
        if (sender == candidate1 && candidateRandomizer == 0) || (sender == candidate2 && candidateRandomizer == 1)         // candidateRandomizer is the correct button image
        {
            let alertController = UIAlertController(title: "Thank you.",
                                                    message: "Congratulations. You are correct!",
                                                    preferredStyle: UIAlertControllerStyle.alert)
            let cancelAction = UIAlertAction(title: "OK",
                                             style: UIAlertActionStyle.cancel,
                                             handler: { (alertAction: UIAlertAction!) in
                                                self.work(categoryRandomizer: Int(arc4random()) % 3, imageRandomizer: Int(arc4random()) % 4)
            }
            )
            alertController.addAction(cancelAction)
            present(alertController, animated: true, completion: nil)
        }
        else
        {
            let alertController = UIAlertController(title: "Thank you.",
                                                    message: "Sorry, you are wrong.",
                                                    preferredStyle: UIAlertControllerStyle.alert)
            let cancelAction = UIAlertAction(title: "OK",
                                             style: UIAlertActionStyle.cancel,
                                             handler: { (alertAction: UIAlertAction!) in
                                                self.work(categoryRandomizer: Int(arc4random()) % 3, imageRandomizer: Int(arc4random()) % 4)
            }
            )
            alertController.addAction(cancelAction)
            present(alertController, animated: true, completion: nil)
        }
    }
    
    @IBAction func newPictures(_ sender: UIButton) {
        work(categoryRandomizer: Int(arc4random()) % 3, imageRandomizer: Int(arc4random()) % 4)
    }
    
    @IBAction func exitToHere(sender: UIStoryboardSegue)
    {
        
    }
    
    func work(categoryRandomizer _: Int, imageRandomizer _: Int) {
        categoryImage.image = images[categoryRandomizer][imageRandomizer]
        unavailable.append(Int(String(categoryRandomizer)+String(imageRandomizer))!)            // add category image to unavailable images
        candidateRandomizer = Int(arc4random()) % 2
        if candidateRandomizer == 0         // if correct candidate is the first one
        {
            while temp == true          // while-loop control
            {
                imageRandomizer = Int(arc4random()) % 4         // randomize image in randomized category until one available is found (get correct candidate)
                if !unavailable.contains(Int(String(categoryRandomizer)+String(imageRandomizer))!)
                {
                    temp = false
                    candidate1.setBackgroundImage(images[categoryRandomizer][imageRandomizer], for: UIControlState.normal)
                }
            }
            unavailable = [34]          // reset unavailable images
            unavailable.append(Int(String(categoryRandomizer)+String(0))!)          // all images in category should be unavailable now
            unavailable.append(Int(String(categoryRandomizer)+String(1))!)
            unavailable.append(Int(String(categoryRandomizer)+String(2))!)
            unavailable.append(Int(String(categoryRandomizer)+String(3))!)
            while temp == false
            {
                categoryRandomizer = Int(arc4random()) % 3 // randomize category and image until one available is found (get incorrect candidate)
                imageRandomizer = Int(arc4random()) % 4
                if !unavailable.contains(Int(String(categoryRandomizer)+String(imageRandomizer))!)
                {
                    temp = true
                    candidate2.setBackgroundImage(images[categoryRandomizer][imageRandomizer], for: UIControlState.normal)
                }
            }
        }
        else            // if correct candidate is the first one
        {
            while temp == true
            {
                imageRandomizer = Int(arc4random()) % 4
                if !unavailable.contains(Int(String(categoryRandomizer)+String(imageRandomizer))!)
                {
                    temp = false
                    candidate2.setBackgroundImage(images[categoryRandomizer][imageRandomizer], for: UIControlState.normal)
                }
            }
            unavailable = [34]
            unavailable.append(Int(String(categoryRandomizer)+String(0))!)
            unavailable.append(Int(String(categoryRandomizer)+String(1))!)
            unavailable.append(Int(String(categoryRandomizer)+String(2))!)
            unavailable.append(Int(String(categoryRandomizer)+String(3))!)
            while temp == false
            {
                categoryRandomizer = Int(arc4random()) % 3
                imageRandomizer = Int(arc4random()) % 4
                if !unavailable.contains(Int(String(categoryRandomizer)+String(imageRandomizer))!)
                {
                    temp = true
                    candidate1.setBackgroundImage(images[categoryRandomizer][imageRandomizer], for: UIControlState.normal)
                }
            }
        }
        unavailable = [34]          // reset unavailable images
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        work(categoryRandomizer: Int(arc4random()) % 3, imageRandomizer: Int(arc4random()) % 4)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

