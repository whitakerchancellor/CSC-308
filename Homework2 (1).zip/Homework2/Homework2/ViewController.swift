//
//  ViewController.swift
//  Homework2
//
//  Created by student on 2/14/18.
//  Copyright © 2018 cs.eku.edu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var cities: UISegmentedControl!
    
    @IBOutlet weak var cityAttractionLabel: UILabel!
    
    @IBOutlet weak var attractionImage: UIImageView!
    
    @IBOutlet weak var attractions: UISegmentedControl!
    
    @IBAction func cityChanged(_ sender: UISegmentedControl) {
        attractions.removeAllSegments()         //remove all segments from the attractions segmented control
        if (sender.selectedSegmentIndex == 0)           //if city = lexington
        {
            attractions.insertSegment(withTitle:"Keeneland", at:0, animated: true)          //set keeneland to first segment
            attractions.insertSegment(withTitle:"Arboretum", at:1, animated: true)          //set arboretum to second segment
        }
        if (sender.selectedSegmentIndex == 1)           //if city = chengdu
        {
            attractions.insertSegment(withTitle:"Panda", at:0, animated: true)          //set panda to first segment
            attractions.insertSegment(withTitle:"Pedestrian Street", at:1, animated: true)          //set pedestrian street to second segment
        }
        if (sender.selectedSegmentIndex == 2)           //if city = chicago
        {
            attractions.insertSegment(withTitle:"Millenium Park", at:0, animated: true)         //set millenium park to first segment
            attractions.insertSegment(withTitle:"Skydeck", at:1, animated: true)            //set skydeck to second segment
            attractions.insertSegment(withTitle:"Cruise", at:2, animated: true)         //set cruise to third segment
            attractions.insertSegment(withTitle:"Planetarium", at:3, animated: true)            //set planetarium to fourth segment
        }
        if (sender.selectedSegmentIndex == 3)           //if city = hongkong
        {
            attractions.insertSegment(withTitle:"Disneyland", at:0, animated: true)         //set disneyland to first segment
            attractions.insertSegment(withTitle:"Ocean Park", at:1, animated: true)         //set ocean park to second segment
            attractions.insertSegment(withTitle:"The Peak", at:2, animated: true)           //set the peak to third segment
        }
        attractions.selectedSegmentIndex = 0            //when the city is changed, the first attraction segment will be selected
        cityAttractionLabel.text = "\(sender.titleForSegment(at: sender.selectedSegmentIndex)!): \(attractions.titleForSegment(at: attractions.selectedSegmentIndex)!)"         //make the label correspond with the first attraction segment
        attractionImage.image = UIImage(named: "\(attractions.titleForSegment(at: attractions.selectedSegmentIndex)!).jpg")         //make the image correspond with the first attraction segment. the image has the same name as the segment
        
    }
    
    @IBAction func attractionChanged(_ sender: UISegmentedControl) {
        cityAttractionLabel.text = "\(cities.titleForSegment(at: cities.selectedSegmentIndex)!): \(sender.titleForSegment(at: sender.selectedSegmentIndex)!)"           //set the label to city: attraction.
        attractionImage.image = UIImage(named: "\(sender.titleForSegment(at: sender.selectedSegmentIndex)!).jpg")           //set the image to the selected attraction segment. the image has the same name as the segment.
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        cityAttractionLabel.text = "\(cities.titleForSegment(at: cities.selectedSegmentIndex)!): \(attractions.titleForSegment(at: attractions.selectedSegmentIndex)!)"         //set the label to lexington: keeneland. it is the default label.
        attractionImage.image = UIImage(named: "\(attractions.titleForSegment(at: attractions.selectedSegmentIndex)!).jpg")         //set the image to keeneland. it is the default image.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

