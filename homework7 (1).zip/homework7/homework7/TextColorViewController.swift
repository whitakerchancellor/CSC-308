//
//  TextColorViewController.swift
//  homework7
//
//  Created by student on 4/3/18.
//  Copyright © 2018 cs@eku.edu. All rights reserved.
//

import UIKit

class TextColorViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    
    @IBOutlet weak var colorPicker: UIPickerView!
    @IBOutlet weak var colorLabel1: UILabel!
    @IBOutlet weak var colorLabel2: UILabel!
    @IBOutlet weak var colorLabel3: UILabel!
    @IBOutlet weak var selectedTextColor: UILabel!
    
    var colorValues = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F"]
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 6
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return colorValues.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return colorValues[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        let initialVC = presentingViewController as! ViewController
        if component == 0 || component == 1
        {
            initialVC.hex0 = colorValues[colorPicker.selectedRow(inComponent: 0)]
            initialVC.hex1 = colorValues[colorPicker.selectedRow(inComponent: 1)]
            initialVC.redD = Int(strtoul(initialVC.hex0+initialVC.hex1, nil, 16))
            colorLabel1.text = String(initialVC.redD)
        } else if component == 2 || component == 3
        {
            initialVC.hex2 = colorValues[colorPicker.selectedRow(inComponent: 2)]
            initialVC.hex3 = colorValues[colorPicker.selectedRow(inComponent: 3)]
            initialVC.greenD = Int(strtoul(initialVC.hex2+initialVC.hex3, nil, 16))
            colorLabel2.text = String(initialVC.greenD)
        } else if component == 4 || component == 5
        {
            initialVC.hex4 = colorValues[colorPicker.selectedRow(inComponent: 4)]
            initialVC.hex5 = colorValues[colorPicker.selectedRow(inComponent: 5)]
            initialVC.blueD = Int(strtoul(initialVC.hex4+initialVC.hex5, nil, 16))
            colorLabel3.text = String(initialVC.blueD)
        }
        selectedTextColor.textColor = UIColor(red: (CGFloat)(initialVC.redD)/255.0, green:
            (CGFloat)(initialVC.greenD)/255.0, blue: (CGFloat)(initialVC.blueD)/255.0, alpha: 1.0)
    }
    
    @IBAction func dismissColorPicker(_ sender: UIButton) {
        (presentingViewController as! ViewController).outputLabel.textColor = selectedTextColor.textColor           
        dismiss(animated: true, completion: nil)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let initialVC = presentingViewController as! ViewController
        colorPicker.selectRow(colorValues.index(of: initialVC.hex0)!, inComponent: 0, animated: true)
        colorPicker.selectRow(colorValues.index(of: initialVC.hex1)!, inComponent: 1, animated: true)
        colorPicker.selectRow(colorValues.index(of: initialVC.hex2)!, inComponent: 2, animated: true)
        colorPicker.selectRow(colorValues.index(of: initialVC.hex3)!, inComponent: 3, animated: true)
        colorPicker.selectRow(colorValues.index(of: initialVC.hex4)!, inComponent: 4, animated: true)
        colorPicker.selectRow(colorValues.index(of: initialVC.hex5)!, inComponent: 5, animated: true)
        colorLabel1.text = String(initialVC.redD)
        colorLabel2.text = String(initialVC.greenD)
        colorLabel3.text = String(initialVC.blueD)
        selectedTextColor.textColor = UIColor(red: (CGFloat)(initialVC.redD)/255.0, green:
            (CGFloat)(initialVC.greenD)/255.0, blue: (CGFloat)(initialVC.blueD)/255.0, alpha: 1.0)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
