//
//  ViewController.swift
//  Homework3
//
//  Created by student on 2/22/18.
//  Copyright © 2018 cs@eku.edu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var gender: UISegmentedControl!
    @IBOutlet weak var weightMeas: UISegmentedControl!
    @IBOutlet weak var waistMeas: UISegmentedControl!
    @IBOutlet weak var weight: UITextField!
    @IBOutlet weak var waist: UITextField!
    @IBOutlet weak var template: UITextView!
    @IBOutlet weak var conclusion: UITextView!
    
    @IBAction func getConclusion(_ sender: UIButton) {
        conclusion.text = template.text     // hidden template with base text
        conclusion.text = conclusion.text.replacingOccurrences(of: "<name>", with: name.text!)      // replace <name> with text field name
        if (gender.selectedSegmentIndex == 0) {     // if gender is male
            conclusion.text = conclusion.text.replacingOccurrences(of: "<bmi>", with: "\((-98.42+4.15*(Double(waist.text!)!*pow(0.393701, Double(waistMeas.selectedSegmentIndex)))-0.082*(Double(weight.text!)!*pow(2.20462, Double(weightMeas.selectedSegmentIndex))))/(Double(weight.text!)!*pow(2.20462, Double(weightMeas.selectedSegmentIndex))))")     // male body fat % formula - if waist measurement is inches, multiply waist by 0.393701^0. if waist measurement is centimeters, multiply waist by 0.393701^1. if weight measurement is pounds, multiply weight by 2.20462^0. if weight measurement is kilograms, multiply weight by 2.20462^1.
        } else {        // if gender is female
            conclusion.text = conclusion.text.replacingOccurrences(of: "<bmi>", with: "\((-76.76+4.15*(Double(waist.text!)!*pow(0.393701, Double(waistMeas.selectedSegmentIndex)))-0.082*(Double(weight.text!)!*pow(2.20462, Double(weightMeas.selectedSegmentIndex))))/(Double(weight.text!)!*pow(2.20462, Double(weightMeas.selectedSegmentIndex))))")     // female body fat % formula
        }
    }
    
    @IBAction func dismissKeyboard(_ sender: Any) {
        self.view.endEditing(true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

