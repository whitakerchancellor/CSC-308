//
//  TransactionsNavigationController.swift
//  Test3
//
//  Created by student on 5/7/18.
//  Copyright © 2018 cs@eku.edu. All rights reserved.
//

import UIKit

class TransactionsNavigationController: UINavigationController {
    
    var month = 0           // shared data to remember which month and category were clicked in the tables
    var category = 0
    
    let months = [
        ("January"),("February"),("March"),("April"),("May"),("June"),("July"),("August"),("September"),("October"),("November"),("December")
    ]
    
    let categories = [
        "Food","Grocery","Transportation","Education","Entertainment","Health"
    ]

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
