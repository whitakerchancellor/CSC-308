//
//  LogActivitiesViewController.swift
//  homework8
//
//  Created by student on 4/17/18.
//  Copyright © 2018 cs@eku.edu. All rights reserved.
//

import UIKit

class LogActivitiesViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    let categories = ["Conditioning Exercise", "Dancing", "Running", "Sports"]
    let activities = [
        "Conditioning Exercise": [("Bicycling",398),("Rope Skipping",699),("Pilates",170),("Yoga",227)],
        "Dancing": [("Ballet",284),("Ballroom Dancing",443)],
        "Running": [("Marathon",755),("Jogging",398)],
        "Sports": [("Badminton",312),("Basketball",369),("Bowling",170),("Boxing",312),("Fencing",341)]
    ]
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return categories.count
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return categories[section]
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return activities[categories[section]]!.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "categoryCell")
        
        cell!.textLabel!.text = activities[categories[indexPath.section]]![indexPath.row].0
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let cell = tableView.cellForRow(at: indexPath)
        
        let alertController = UIAlertController(title: "Activity Duration",
                                                message: "How many hours did you exercise?",
                                                preferredStyle: UIAlertControllerStyle.alert)
        
        alertController.addTextField(configurationHandler: {(textField: UITextField) in
            textField.keyboardType = UIKeyboardType.decimalPad
        }
        )
        
        let defaultAction = UIAlertAction(title: "OK",
                                          style: UIAlertActionStyle.cancel,
                                          handler: { (alertAction: UIAlertAction!) in
                                            let hours = alertController.textFields![0].text!
                                            cell!.detailTextLabel!.text = "\(hours) hours"
                                            tableView.reloadRows(at: [indexPath], with: UITableViewRowAnimation.automatic)
        }
        )
        
        alertController.addAction(defaultAction)                    // add action button into the alert window
        
        present(alertController, animated: true, completion: nil)   // display the alert window
        
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
