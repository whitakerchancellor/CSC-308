//
//  PlantAnimalNameViewController.swift
//  homework7
//
//  Created by student on 4/3/18.
//  Copyright © 2018 cs@eku.edu. All rights reserved.
//

import UIKit

class PlantAnimalNameViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {
    
    @IBOutlet weak var namePicker: UIPickerView!
    @IBOutlet weak var imageVieww: UIImageView!
    
    var components = [
        (["Plant", "Animal"], ["Plant", "Animal"]),
        (["Dandelion", "Beargrass", "Hibiscus"], ["Panda", "Elephant", "Lion", "Penguin", "Wolf", "Bear"])
    ]
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return components.count
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if namePicker.selectedRow(inComponent: 0) == 0
        {
            return components[component].0.count
        }
        return components[component].1.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if namePicker.selectedRow(inComponent: 0) == 0
        {
            return components[component].0[row]
        }
        return components[component].1[row]
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if component == 0
        {
            namePicker.reloadComponent(1)
        }
        if namePicker.selectedRow(inComponent: 0) == 0
        {
            imageVieww.image =  UIImage(named: "\(components[1].0[namePicker.selectedRow(inComponent: 1)]).png")
        }
        else if namePicker.selectedRow(inComponent: 0) == 1
        {
            imageVieww.image =  UIImage(named: "\(components[1].1[namePicker.selectedRow(inComponent: 1)]).png")
        }
    }
    
    @IBAction func dismissNamePicker(_ sender: UIButton) {
        let initialVC = presentingViewController as! ViewController
        if namePicker.selectedRow(inComponent: 0) == 0          
        {
            initialVC.name = components[1].0[namePicker.selectedRow(inComponent: 1)]
            initialVC.typeRow = 0
        } else if namePicker.selectedRow(inComponent: 0) == 1
        {
            initialVC.name = components[1].1[namePicker.selectedRow(inComponent: 1)]
            initialVC.typeRow = 1
        }
        dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        /*
        let initialVC = presentingViewController as! ViewController
        if initialVC.typeRow == 0
        {
            initialVC.nameRow = components[1].0.index(of: initialVC.name)!
        }
        else
        {
            initialVC.nameRow = components[1].1.index(of: initialVC.name)!
        }
        namePicker.selectRow(initialVC.typeRow, inComponent: 0, animated: true)
        namePicker.selectRow(initialVC.nameRow, inComponent: 1, animated: true)
        imageVieww.image = UIImage(named: "\(initialVC.name).jpg")
 */
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let initialVC = presentingViewController as! ViewController
        if initialVC.typeRow == 0
        {
            initialVC.nameRow = components[1].0.index(of: initialVC.name)!
        }
        else
        {
            initialVC.nameRow = components[1].1.index(of: initialVC.name)!
        }
        namePicker.selectRow(initialVC.typeRow, inComponent: 0, animated: true)
        namePicker.selectRow(initialVC.nameRow, inComponent: 1, animated: true)
        imageVieww.image = UIImage(named: "\(initialVC.name).jpg")
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
