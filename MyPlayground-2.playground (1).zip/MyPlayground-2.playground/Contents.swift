//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"

var products: [String: (String, Double)] = ["Apples": ("Food", 3.99), "Oranges": ("Food", 2.99), "Bananas": ("Food", 1.99), "Phone": ("Electronics", 499.99), "Computer": ("Electronics", 999.99)]

func lowestPrice(products: [String: (String, Double)]) -> (name: String, price: Double)
{
    var lowest: (key: String, value: (String, Double)) = ("Placeholder1", ("Placeholder2", Double(Int.max)))
    for t in products
    {
        if t.value.1 < lowest.value.1
        {
            lowest = t
        }
    }
    return (lowest.key, lowest.value.1)
}

func highestPrice(products: [String: (String, Double)]) -> (name: String, price: Double)
{
    var highest: (key: String, value: (String, Double)) = ("Placeholder1", ("Placeholder2", 0))
    for t in products
    {
        if t.value.1 > highest.value.1
        {
            highest = t
        }
    }
    return (highest.key, highest.value.1)
}

func price(products: [String: (String, Double)], funcName: ([String: (String, Double)])->(String, Double)) -> (String, Double)
{
    return funcName(products)
}

price(products: products, funcName: lowestPrice)
price(products: products, funcName: highestPrice)
