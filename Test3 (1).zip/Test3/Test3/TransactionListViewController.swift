//
//  TransactionListViewController.swift
//  Test3
//
//  Created by student on 5/7/18.
//  Copyright © 2018 cs@eku.edu. All rights reserved.
//

import UIKit
import CoreData

class TransactionListViewController: UIViewController {
    let managedObjectContext = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    @IBOutlet weak var transactionListText: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let parentVC = (parent as! TransactionsNavigationController)
        transactionListText.text = "Spending on \(parentVC.categories[parentVC.category]) in \(parentVC.months[parentVC.month])"
        let fetchRequest = NSFetchRequest<Transactions>(entityName: "Transactions")
        fetchRequest.predicate = NSCompoundPredicate(type:.and, subpredicates:[
            NSPredicate(format: "month = %@", parentVC.months[parentVC.month]),
            NSPredicate(format: "category = %@", parentVC.categories[parentVC.category])])          // two predicates
        do {
            let results = try managedObjectContext.fetch(fetchRequest)
            for r in results {
                transactionListText.text = transactionListText.text + "\n\t\(r.month!) \(r.day!): $\(r.amount!) \(r.note!)"
            }
        } catch {
            transactionListText.text = error.localizedDescription
        }
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
