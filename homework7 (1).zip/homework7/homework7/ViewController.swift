//
//  ViewController.swift
//  homework7
//
//  Created by student on 4/3/18.
//  Copyright © 2018 cs@eku.edu. All rights reserved.
//

import UIKit
import WebKit

class ViewController: UIViewController {
    
    var name = "Dandelion"
    var nameRow = 0
    var typeRow = 0
    var hex0 = "0"
    var hex1 = "0"
    var hex2 = "0"
    var hex3 = "0"
    var hex4 = "0"
    var hex5 = "0"
    var redD = 0
    var greenD = 0
    var blueD = 0
    
    @IBOutlet weak var outputLabel: UILabel!
    @IBOutlet weak var webView: WKWebView!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var chooseNameBarButtonItem: UIBarButtonItem!
    
    @IBAction func showNewScene(_ sender: AnyObject) {
        if sender === chooseNameBarButtonItem
        {
            performSegue(withIdentifier: "toNamePicker", sender: sender)
        }
        else
        {
            performSegue(withIdentifier: "toColorPicker", sender: sender)
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //imageView.image = UIImage(named: "Dandelion.jpg")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        outputLabel.text = name
        imageView.image = UIImage(named: "\(name).jpg")
        let wikiURLStr = "http://www.wikipedia.org/wiki/\(name)"
        if let wikiURL = URL(string: wikiURLStr)
        {
            webView.load(URLRequest(url: wikiURL))       
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

