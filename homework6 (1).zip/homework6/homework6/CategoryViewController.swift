//
//  CategoryViewController.swift
//  homework6
//
//  Created by student on 3/22/18.
//  Copyright © 2018 cs@eku.edu. All rights reserved.
//

import UIKit

class CategoryViewController: UIViewController {
    
    
    @IBAction func flowerSelected(_ sender: UIButton) {
        (presentingViewController as! ViewController).categoryRandomizer = 0            // set category for category image to flower
        (presentingViewController as! ViewController).imageRandomizer = Int(arc4random()) % 4
        (presentingViewController as! ViewController).work(categoryRandomizer: (presentingViewController as! ViewController).categoryRandomizer, imageRandomizer: (presentingViewController as! ViewController).imageRandomizer)
    }
    
    @IBAction func foodSelected(_ sender: UIButton) {
        (presentingViewController as! ViewController).categoryRandomizer = 1            // set category for category image to food
        (presentingViewController as! ViewController).imageRandomizer = Int(arc4random()) % 4
        (presentingViewController as! ViewController).work(categoryRandomizer: (presentingViewController as! ViewController).categoryRandomizer, imageRandomizer: (presentingViewController as! ViewController).imageRandomizer)
    }
    
    @IBAction func vehicleSelected(_ sender: UIButton) {
        (presentingViewController as! ViewController).categoryRandomizer = 2            // set category for category image to vehicle
        (presentingViewController as! ViewController).imageRandomizer = Int(arc4random()) % 4
        (presentingViewController as! ViewController).work(categoryRandomizer: (presentingViewController as! ViewController).categoryRandomizer, imageRandomizer: (presentingViewController as! ViewController).imageRandomizer)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
