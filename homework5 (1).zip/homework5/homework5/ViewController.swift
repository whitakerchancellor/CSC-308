//
//  ViewController.swift
//  homework5
//
//  Created by student on 3/8/18.
//  Copyright © 2018 cs@eku.edu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var count = 0           // counter to record how many dollar buttons have been pressed
    var temp = true         // temp boolean to control while loop
    var numbers = [6]           // integer array to remember which numbers have already been drawn
    var randNum = 0         // number drawn
    var total = 0           // variable to update player's winnings
    @IBOutlet weak var outputLabel: UILabel!
    @IBOutlet weak var button1: UIButton!
    @IBOutlet weak var button2: UIButton!
    @IBOutlet weak var button3: UIButton!
    @IBOutlet weak var button4: UIButton!
    @IBOutlet weak var button5: UIButton!
    @IBOutlet weak var button6: UIButton!
    
    @IBAction func helpAlert(_ sender: UIButton) {
        let alertController = UIAlertController(title: "How To Play",
                                                message: "Click two buttons to find your award",
                                                preferredStyle: UIAlertControllerStyle.alert)
        
        let defaultAction = UIAlertAction(title: "OK",
                                          style: UIAlertActionStyle.cancel,
                                          handler: nil)
        
        alertController.addAction(defaultAction)
        
        present(alertController, animated: true, completion: nil)
    }
    
    @IBAction func button1Clicked(_ sender: UIButton) {
        if count < 2
        {
            temp = true         // reset temp so while loop can function
            count = count + 1           // iterate counter every time a dollar button is pressed
            sender.setBackgroundImage(nil, for: UIControlState.normal)          // remove background image
            sender.isEnabled = false            // button cannot be pressed twice
            while (temp == true)
            {
                randNum = Int(arc4random()) % 6         // generate number "behind" dollar sign
                if !numbers.contains(randNum)           // if the number hasn't been drawn yet
                {
                    temp = false            // change temp so we can escape while loop
                    numbers.append(randNum)         // add drawn number to array
                    sender.setTitle("\(randNum*100)", for: UIControlState.normal)           // display number
                }
            }
            total = total + randNum*100         // accumulate total
            outputLabel.text = "You've got \(total) dollars!"           // display total after every button press
        }
        if count == 2
        {
            let alertController = UIAlertController(title: "Congratulations",
                                                    message: outputLabel.text,
                                                    preferredStyle: UIAlertControllerStyle.alert)
            
            let nowAction = UIAlertAction(title: "Play Again",
                                          style: UIAlertActionStyle.default,
                                          handler: { (alertAction: UIAlertAction!) in
                                            self.button1.isEnabled = true           // re-enable buttons
                                            self.button2.isEnabled = true
                                            self.button3.isEnabled = true
                                            self.button4.isEnabled = true
                                            self.button5.isEnabled = true
                                            self.button6.isEnabled = true
                                            self.button1.setBackgroundImage(UIImage(named: "dollar1.jpg"), for: UIControlState.normal)          // re-enable images
                                            self.button2.setBackgroundImage(UIImage(named: "dollar1.jpg"), for: UIControlState.normal)
                                            self.button3.setBackgroundImage(UIImage(named: "dollar1.jpg"), for: UIControlState.normal)
                                            self.button4.setBackgroundImage(UIImage(named: "dollar1.jpg"), for: UIControlState.normal)
                                            self.button5.setBackgroundImage(UIImage(named: "dollar1.jpg"), for: UIControlState.normal)
                                            self.button6.setBackgroundImage(UIImage(named: "dollar1.jpg"), for: UIControlState.normal)
                                            self.button1.setTitle(nil, for: UIControlState.normal)          // remove numbers
                                            self.button2.setTitle(nil, for: UIControlState.normal)
                                            self.button3.setTitle(nil, for: UIControlState.normal)
                                            self.button4.setTitle(nil, for: UIControlState.normal)
                                            self.button5.setTitle(nil, for: UIControlState.normal)
                                            self.button6.setTitle(nil, for: UIControlState.normal)
                                            self.outputLabel.text = nil         // reset output label
                                            self.count = 0          // reset counter
                                            self.numbers = [6]          // reset drawn numbers array
                                            self.total = 0          // reset total
            }
            )
            let cancelAction = UIAlertAction(title: "Exit",
                                             style: UIAlertActionStyle.cancel,
                                             handler: { (alertAction: UIAlertAction!) in
                                                exit(0)
            }
            )
            
            alertController.addAction(nowAction)
            alertController.addAction(cancelAction)
            
            present(alertController, animated: true, completion: nil)
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

